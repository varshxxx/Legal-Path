// require('dotenv').config();
// const fs = require('fs');
// const path = require('path');
// const pdfParse = require('pdf-parse');  // For parsing PDF content
// const { GoogleGenerativeAI } = require('@google/generative-ai');

// // Function to extract text from PDF
// async function extractFIRText(filePath) {
//   try {
//     const dataBuffer = fs.readFileSync(filePath);
//     const data = await pdfParse(dataBuffer);
//     return data.text;  // Extracted text from PDF
//   } catch (error) {
//     console.error('Error extracting FIR text:', error);
//     return null;
//   }
// }

// // Function to parse FIR text and populate the case details object
// function parseFIRText(firText) {
//   const caseDetails = {};

//   // Extracting details using regex and populating caseDetails object
//   caseDetails.offense = firText.match(/Offense:\s*(.*)/)?.[1] || 'Not mentioned';
//   caseDetails.accusedBackground = firText.match(/Accused Background:\s*(.*)/)?.[1] || 'Not mentioned';
//   caseDetails.legalSections = firText.match(/Legal Sections:\s*(.*)/)?.[1] || 'Not mentioned';
//   caseDetails.courtJurisdiction = firText.match(/Court Jurisdiction:\s*(.*)/)?.[1] || 'Not mentioned';
//   caseDetails.additionalFactors = firText.match(/Additional Factors:\s*(.*)/)?.[1] || 'Not mentioned';
//   console.log(caseDetails);
//   return caseDetails;
// }

// // Function to format the prompt for Gemini API based on extracted details
// function formatPrompt(caseDetails) {
//   return `You are a legal assistant specialized in drafting bail applications. First, print the case details and provide legal suggestions based on the Indian Penal Code (IPC) and other Indian laws. Analyze the case details below and draft a suggestion for a bail application, citing the relevant sections of the law:
  
//   Case Details:
//   Offense: ${caseDetails.offense}
//   Accused Background: ${caseDetails.accusedBackground}
//   Legal Sections Applicable: ${caseDetails.legalSections}
//   Court Jurisdiction: ${caseDetails.courtJurisdiction}
//   Additional Factors: ${caseDetails.additionalFactors}
  
//   Draft the bail decision based on the Indian Constitution alone without disclaimers, focusing solely on legal interpretation in points and highlighting the sections. If there is any solved case similar to this, quote it without a disclaimer based on the details and tell whether bail can be granted or not based on the points.`;
// }

// // Query Gemini API with the formatted prompt
// async function queryGemini() {
//   try {
//     const genAI = new GoogleGenerativeAI(process.env.API_KEY);
//     const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

//     // Path to your FIR PDF file
//     const firText = await extractFIRText(path.join(__dirname, 'FIR.pdf'));
    
//     if (!firText) {
//       console.error('Failed to extract FIR text');
//       return;
//     }

//     // Parse the FIR text to extract details and format the prompt
//     const caseDetails = parseFIRText(firText);
//     const prompt = formatPrompt(caseDetails);
    
//     // Sending the prompt to Gemini API
//     const result = await model.generateContent(prompt);

//     const generatedText = result.response.candidates[0]?.content || 'No content generated.';
//     console.log("Generated Text:", generatedText);
    
//   } catch (error) {
//     console.error('Error querying Gemini:', error);
//   }
// }

// queryGemini();
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const pdfParse = require('pdf-parse');  // For parsing PDF content
const { GoogleGenerativeAI } = require('@google/generative-ai');

// Function to extract text from PDF
async function extractFIRText(filePath) {
  try {
    const dataBuffer = fs.readFileSync(filePath);
    const data = await pdfParse(dataBuffer);
    return data.text;  // Extracted text from PDF
  } catch (error) {
    console.error('Error extracting FIR text:', error);
    return null;
  }
}

// Query Gemini API with the full FIR text
async function queryGemini() {
  try {
    const genAI = new GoogleGenerativeAI(process.env.API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    // Path to your FIR PDF file
    const firText = await extractFIRText(path.join(__dirname, 'FIR.pdf'));
    
    if (!firText) {
      console.error('Failed to extract FIR text');
      return;
    }

    // Prepare the prompt by sending the full FIR content to Gemini
    const prompt = `
      You are a legal assistant specialized in analyzing legal documents and providing suggestions based on the Indian Penal Code (IPC) and other Indian laws. 
      Do not provide any disclaimers YOU ARE LEGAL ASSISTANT 
      You are providing this details to judges to build a bail petition 
      Analyze the following FIR document and provide the following information:
      1. Offense
      2. Accused Background
      3. Legal Sections Applicable
      4. Court Jurisdiction
      5. Additional Factors

      Based on the details you extract, draft a suggestion for a bail application, citing the relevant sections of the law. Include any similar solved case references if available, and conclude with whether bail should be granted or not, based on legal interpretations and Indian Constitution.
      and provide a line the bail is granded or not
      Here is the FIR document content:
      ${firText}

      Please extract and analyze the data as per the requirements above.
    `;
    
    // Sending the prompt to Gemini API
    const result = await model.generateContent(prompt);

    const generatedText = result.response.candidates[0]?.content || 'No content generated.';
    console.log("Generated Text:", generatedText.parts);
    
  } catch (error) {
    console.error('Error querying Gemini:', error);
  }
}

queryGemini();
