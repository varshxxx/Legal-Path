// require('dotenv').config();
// const express = require('express');
// const multer = require('multer');
// const cors = require('cors');
// const fs = require('fs');
// const path = require('path');
// const pdfParse = require('pdf-parse');
// const { GoogleGenerativeAI } = require('@google/generative-ai');

// const app = express();
// const port = 3000;
// app.use(cors());

// // Setup file upload using Multer
// const storage = multer.memoryStorage();
// const upload = multer({ storage: storage });



// async function extractFIRText(fileBuffer) {
//     try {
//         const data = await pdfParse(fileBuffer);
//         console.log(data.text);  // Log extracted text for debugging
//         return data.text;
//     } catch (error) {
//         console.error('Error extracting FIR text:', error);
//         return null;
//     }
// }

// app.post('/process-bail-petition', (req, res) => {
//     try {
//         const { bailPetition, fileName } = req.body;

//         if (!bailPetition || !fileName) {
//             return res.status(400).json({ error: 'Bail petition and file name are required' });
//         }

//         // Process the bail petition
//         const result = processBailPetition(bailPetition, fileName);

//         res.status(200).json({
//             message: 'Bail petition processed successfully',
//             result
//         });
//     } catch (error) {
//         console.error('Error processing bail petition:', error);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// });

// async function queryGemini(firText) {
//     try {
//         const genAI = new GoogleGenerativeAI(process.env.API_KEY);
//         const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

//         const prompt = `
//             You are a legal assistant specialized in analyzing legal documents that contains both tamil and english languages.and providing suggestions based on the Indian Penal Code (IPC) and other Indian laws. 
//             help the lawyer in drafting the bail petitions and what the sections say in detail

//             Do not provide any disclaimers
//             You are providing this details to lawyers to build a BAIL PETITION
//             Analyze the following FIR document and provide the following information:
//             1. Offense
//             2. Accused Background
//             3. Legal Sections Applicable
//             4. Court Jurisdiction
//             5. Additional Factors

//             Given the following details from an FIR, generate a BAIL PETITION Cr.P.C. The FIR contains the following key information:

//             Accused Details: Provide the names and background details (e.g., educational or professional background) of the accused only if it is present in the FIR, if it si not present dont provide it .
//             Alleged Offences: List the specific sections of the Indian Penal Code (IPC) under which the accused are charged.
//             Incident Details: Include the date of the alleged offence and any relevant information about the nature of the incident.
//             Arrest/Remand Details: Specify whether the accused were arrested, remanded to judicial custody, and if so, the date of such remand.
//             Involvement of the Accused: State whether the accused are named in the FIR, or if they are merely under suspicion.
//             Claims of Innocence: Include any claims of innocence or prior enmity mentioned by the accused.
//             Bail Conditions: Mention if the accused are willing to furnish sureties, cooperate with the trial, and comply with any conditions set by the court.
//             Previous Cases: Note if the accused have been involved in any previous criminal cases or if this is their first bail application.
//             Request for Bail: Conclude by requesting the court to grant bail to the accused based on the above information.
//             Please generate the bail petition in a formal and structured format based on the above details, emphasizing the request for bail, the accused's willingness to cooperate, and the context of the case.

//             Here is the FIR document content:
//             ${firText}
//             Please extract and analyze the data as per the requirements above.
            
//         `;

//         const result = await model.generateContent(prompt);
       

//         const generateText= result.response.candidates[0]?.content;
//         console.log(generateText.parts[0].text);
//         return generateText.parts[0].text || 'No content generated.';
//     } catch (error) {
//         console.error('Error querying Gemini:', error);
//         return null;
//     }
// }

// function processBailPetition(bailPetition, fileName) {
//     // Extract details using regex
//     const caseIdMatch = bailPetition.match(/Case ID:\s*(.+)/i);
//     const petitionerNameMatch = bailPetition.match(/Petitioner Name:\s*(.+)/i);
//     const lawyerNameMatch = bailPetition.match(/Lawyer Name:\s*(.+)/i);

//     const details = {
//         caseId: caseIdMatch ? caseIdMatch[1].trim() : 'Not Found',
//         petitionerName: petitionerNameMatch ? petitionerNameMatch[1].trim() : 'Not Found',
//         lawyerName: lawyerNameMatch ? lawyerNameMatch[1].trim() : 'Not Found',
//         documentPath: ''
//     };

//     // Save the bail petition document locally
//     const storageDir = path.join(__dirname, 'documents');
//     if (!fs.existsSync(storageDir)) {
//         fs.mkdirSync(storageDir); // Create directory if it doesn't exist
//     }

//     const filePath = path.join(storageDir, fileName);
//     fs.writeFileSync(filePath, bailPetition); // Save the bail petition as a text file

//     // Update details with file path
//     details.documentPath = filePath;

//     // Save details to data.json
//     const jsonFilePath = path.join(__dirname, 'data.json');
//     let existingData = [];

//     // Read existing data if the file exists
//     if (fs.existsSync(jsonFilePath)) {
//         const fileContent = fs.readFileSync(jsonFilePath, 'utf-8');
//         existingData = JSON.parse(fileContent);
//     }

//     // Append new data
//     existingData.push(details);
//     fs.writeFileSync(jsonFilePath, JSON.stringify(existingData, null, 2));

//     return details;
// }



// app.post('/generate-bail-petition', upload.single('firPdf'), async (req, res) => {
//     try {
//         // Step 1: Save the uploaded PDF to a directory
//         const filePath = path.join(__dirname, 'uploads', req.file.originalname); // Ensure you have an "uploads" directory
//         fs.writeFileSync(filePath, req.file.buffer);  // Store the PDF in the 'uploads' directory

//         // Step 2: Extract text from the uploaded FIR PDF
//         const firText = await extractFIRText(req.file.buffer);
//         if (!firText) {
//             return res.status(400).json({ error: 'Failed to extract FIR text' });
//         }

//         // Step 3: Extract data (lawyer name, case number, petitioner name) from the FIR text
//         const extractedData = {
//             lawyerName: extractLawyerName(firText),
//             caseNumber: extractCaseNumber(firText),
//             petitionerName: extractPetitionerName(firText),
//             filePath: filePath  // Store the path to the PDF file
//         };

//         // Step 4: Store the extracted data in a JSON file
//         const jsonFilePath = path.join(__dirname, 'data.json');
//         let data = [];
        
//         if (fs.existsSync(jsonFilePath)) {
//             data = JSON.parse(fs.readFileSync(jsonFilePath, 'utf-8')); // Read existing data
//         }
        
//         data.push(extractedData);  // Add the new data to the array
//         fs.writeFileSync(jsonFilePath, JSON.stringify(data, null, 2));  // Save to JSON file
        
//         // Step 5: Return the extracted data as JSON response
//         res.json({ extractedData });

//     } catch (error) {
//         console.error('Error in /generate-bail-petition:', error);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// });

// // Helper functions to extract required information from FIR text
// function extractLawyerName(firText) {
//     // Implement logic to extract lawyer name from FIR text (you can use regex or string matching)
//     return firText.match(/Lawyer Name: (.*?)(?=\n|$)/)?.[1] || 'Unknown';
// }

// function extractCaseNumber(firText) {
//     // Implement logic to extract case number from FIR text
//     return firText.match(/Case Number: (.*?)(?=\n|$)/)?.[1] || 'Unknown';
// }

// function extractPetitionerName(firText) {
//     // Implement logic to extract petitioner name from FIR text
//     return firText.match(/Petitioner Name: (.*?)(?=\n|$)/)?.[1] || 'Unknown';
// }
// // Serve the frontend files (optional if using separate frontend)
// app.use(express.static('public'));

// // Start server
// app.listen(port, () => {
//     console.log(`Server running on http://localhost:${port}`);
// });

require('dotenv').config();
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const pdfParse = require('pdf-parse');
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const port = 3000;
app.use(cors());

// Setup file upload using Multer
const storage = multer.memoryStorage();
const upload = multer({ dest: 'uploads/' });



async function extractFIRText(fileBuffer) {
    try {
        const data = await pdfParse(fileBuffer);
        console.log(data.text);  // Log extracted text for debugging
        return data.text;
    } catch (error) {
        console.error('Error extracting FIR text:', error);
        return null;
    }
}



async function queryGemini(firText) {
    try {
        const genAI = new GoogleGenerativeAI(process.env.API_KEY);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = `
            You are a legal assistant specialized in analyzing legal documents that contains both tamil and english languages.and providing suggestions based on the Indian Penal Code (IPC) and other Indian laws. 
            help the lawyer in drafting the bail petitions and what the sections say in detail

            Do not provide any disclaimers
            You are providing this details to lawyers to build a BAIL PETITION
            Analyze the following FIR document and provide the following information:
            1. Offense
            2. Accused Background
            3. Legal Sections Applicable
            4. Court Jurisdiction
            5. Additional Factors

            Given the following details from an FIR, generate a BAIL PETITION Cr.P.C. The FIR contains the following key information:

            Accused Details: Provide the names and background details (e.g., educational or professional background) of the accused only if it is present in the FIR, if it si not present dont provide it .
            Alleged Offences: List the specific sections of the Indian Penal Code (IPC) under which the accused are charged.
            Incident Details: Include the date of the alleged offence and any relevant information about the nature of the incident.
            Arrest/Remand Details: Specify whether the accused were arrested, remanded to judicial custody, and if so, the date of such remand.
            Involvement of the Accused: State whether the accused are named in the FIR, or if they are merely under suspicion.
            Claims of Innocence: Include any claims of innocence or prior enmity mentioned by the accused.
            Bail Conditions: Mention if the accused are willing to furnish sureties, cooperate with the trial, and comply with any conditions set by the court.
            Previous Cases: Note if the accused have been involved in any previous criminal cases or if this is their first bail application.
            Request for Bail: Conclude by requesting the court to grant bail to the accused based on the above information.
            Please generate the bail petition in a formal and structured format based on the above details, emphasizing the request for bail, the accused's willingness to cooperate, and the context of the case.

            Here is the FIR document content:
            ${firText}
            Please extract and analyze the data as per the requirements above.
            
        `;

        const result = await model.generateContent(prompt);
       

        const generateText= result.response.candidates[0]?.content;
        console.log(generateText.parts[0].text);
        return generateText.parts[0].text || 'No content generated.';
    } catch (error) {
        console.error('Error querying Gemini:', error);
        return null;
    }
}

// Endpoint to handle file upload and bail petition generation
app.post('/generate-bail-petition', upload.single('firPdf'), async (req, res) => {
    try {
        const firText = await extractFIRText(req.file.buffer);
        if (!firText) {
            return res.status(400).json({ error: 'Failed to extract FIR text' });
        }
        
        const bailPetition = await queryGemini(firText);
        if (!bailPetition) {
            return res.status(500).json({ error: 'Failed to generate bail petition' });
        }

        res.json({ bailPetition });
    } catch (error) {
        console.error('Error in /generate-bail-petition:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


app.post('/upload', upload.single('file'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded.' });
    }

    const filePath = path.join(__dirname, req.file.path);
    try {
        const dataBuffer = fs.readFileSync(filePath);
        const pdfData = await pdfParse(dataBuffer);
        
        // Extract data (use regex or custom logic based on your PDF format)
        const caseNumberMatch = pdfData.text.match(/Case Number:\s*(\S+)/i);
        const petitionerMatch = pdfData.text.match(/Petitioner:\s*([\w\s]+)/i);
        const lawyerMatch = pdfData.text.match(/Lawyer:\s*([\w\s]+)/i);

        const extractedData = {
            caseNumber: caseNumberMatch ? caseNumberMatch[1] : 'Unknown',
            petitionerName: petitionerMatch ? petitionerMatch[1].trim() : 'Unknown',
            lawyerName: lawyerMatch ? lawyerMatch[1].trim() : 'Unknown',
            pdfPath: filePath,
        };

        // Save data to data.json
        const jsonDataPath = path.join(__dirname, 'data.json');
        let jsonData = [];

        if (fs.existsSync(jsonDataPath)) {
            jsonData = JSON.parse(fs.readFileSync(jsonDataPath, 'utf-8'));
        }

        jsonData.push(extractedData);
        fs.writeFileSync(jsonDataPath, JSON.stringify(jsonData, null, 2));

        res.status(200).json({ message: 'File uploaded and data extracted successfully.' });
    } catch (error) {
        console.error('Error processing PDF:', error);
        res.status(500).json({ message: 'Failed to process the file.' });
    } finally {
        // Clean up uploaded file
        fs.unlinkSync(filePath);
    }
});
// Serve the frontend files (optional if using separate frontend)
app.use(express.static('public'));

// Start server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});