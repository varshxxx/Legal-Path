// index.js
const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('./db');

const app = express();
app.set('view engine', 'ejs');
app.use(express.static('uploads'));

// Configure Multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

// Route to display lawyers and their cases
app.get('/', (req, res) => {
    const query = `
        SELECT lawyers.id AS lawyer_id, lawyers.name AS lawyer_name, cases.fir_file_path, cases.bail_petition_path
        FROM lawyers
        LEFT JOIN cases ON lawyers.id = cases.lawyer_id;
    `;
    db.query(query, (err, results) => {
        if (err) throw err;
        res.render('index', { lawyers: results });
    });
});

// Route to handle file uploads
app.post('/submit', upload.fields([{ name: 'fir_file' }, { name: 'bail_petition' }]), (req, res) => {
    const { lawyer_id } = req.body;
    const firFilePath = req.files['fir_file'][0].path;
    const bailPetitionPath = req.files['bail_petition'][0].path;

    const query = `INSERT INTO cases (lawyer_id, fir_file_path, bail_petition_path) VALUES (?, ?, ?)`;
    db.query(query, [lawyer_id, firFilePath, bailPetitionPath], (err, results) => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Start the server
app.listen(3000, () => {
    console.log('Server started on http://localhost:3000');
});
