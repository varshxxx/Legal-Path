const express = require("express");
const mysql = require("mysql2");

const app = express();
const PORT = 3000;

// Middleware to parse JSON requests
app.use(express.json());

// MySQL database connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "#Priyanka2005",
  database: "bailreckoner",
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL database:", err);
    return;
  }
  console.log("Connected to MySQL database");
});

// Simple GET endpoint to fetch user data by username and aadhar number
app.get("/user", (req, res) => {
  const { username, aadhar_number } = req.query;

  // Query to get user data based on username and aadhar number
  const query = "SELECT * FROM users WHERE username = ? AND adhaarNumber = ?";

  db.query(query, [username, aadhar_number], (err, results) => {
    if (err) {
      console.error("Database query error:", err);
      return res.status(500).json({ message: "Internal server error." });
    }

    if (results.length === 0) {
      return res.status(404).json({ message: "User not found." });
    }

    // Return the found user data
    res.status(200).json({
      message: "User found.",
      userData: results[0],
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
