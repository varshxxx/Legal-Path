require('dotenv').config();
const axios = require('axios');
const cheerio = require('cheerio');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const path = require('path'); // Importing path module
const fs = require('fs'); // Importing fs module
// Initialize the Gemini API client
const genAI = new GoogleGenerativeAI({
  apiKey: process.env.GEMINI_API_KEY, // Your Gemini API key
});

// Function to format the scraped judgment content into a prompt
function formatPrompt(judgmentContent) {
  return `
  You are a legal assistant trained to extract specific details from legal judgments. Based on the following content, provide the following details. If any information is missing, return "null" for that field in the next next lines without gap or dont leave line inbetween results:

  1. Case Name (Example: State of XYZ vs. John Doe)
  2. Relevant Legal Sections (Example: IPC 302, IPC 34)
  3. Crime Committed (Brief description, Example: Theft, Assault)
  4. Risk of Flight (Yes/No)
  5. City and State of the Case (Example: Mumbai, Maharashtra)
  6. Bail Status (Granted/Denied)
  7.. Court Name (Example: Supreme Court of India)
  8. Name of the Judge (Full Name)
  9.The damage(The amount stolen,rthe amount damaged, the people kidded,the raped one)

  Judgment Content:
  ${judgmentContent}
  `;
}

const csvWriter = createCsvWriter({
  path: 'judgment_data.csv',
  header: [
    { id: 'caseName', title: 'Case Name' },
    { id: 'sections', title: 'Relevant Legal Sections' },
    { id: 'crime', title: 'Crime Committed' },
    { id: 'riskOfFlight', title: 'Risk of Flight' },
    { id: 'cityState', title: 'City and State' },
    { id: 'bailStatus', title: 'Bail Status' },
    { id: 'courtName', title: 'Court Name' },
    { id: 'judgeName', title: 'Judge Name' },
    {id: 'damage', title: 'damage'}
  ],
});

async function queryGemini(judgmentContent) {
  try {
  
    const prompt = formatPrompt(judgmentContent);

    const genAI = new GoogleGenerativeAI(process.env.API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    
    // Sending the prompt to Gemini API
    const result = await model.generateContent(prompt);
    //console.log("Full Result:", result);

    const candidate = result.response.candidates[0];
      
      // Check if candidate has 'content.parts' and extract the text
      if (candidate.content && candidate.content.parts && candidate.content.parts.length > 0) {
        const generatedText = candidate.content.parts[0];  // Assuming first part is the content you need

        //console.log('Generated Text:', generatedText.text);

      return parseGeneratedText(generatedText.text);
    } else {
      console.log("No candidates found in the response.");
      return null;
    }
  }
  catch(e)
  {
    console.log(e);
  }

}


async function fetchJudgmentContent(url) {
    try {
      // Send GET request to the URL
      const response = await axios.get(url);
      
      // Load the HTML content into Cheerio
      const $ = cheerio.load(response.data);
      
      // Initialize an array to hold the extracted content
      const judgmentContent = [];
      
      // First, extract content from the '.judgments' class
      $('div.judgments p').each((index, element) => {
        const text = $(element).text().trim();
        if (text) {
          judgmentContent.push(text);
        }
      });
  
      // Then, extract content from '.expanded_headline .fragment p' if needed
      $('.doc_title').each((index, element) => {
        const text = $(element).text().trim();
        if (text) {
          judgmentContent.push(text);
        }
      });

  
      // Return the content or throw an error if no content was found
      if (judgmentContent.length > 0) {
       // console.log(judgmentContent.join("\n"));
        return judgmentContent.join("\n"); // Join the content with new lines for readability
      } else {
        throw new Error('No judgment content found.');
      }
    } catch (error) {
      console.error('Error scraping the judgment:', error);
      throw error;
    }
  }

 // Parse the generated text into structured data
//  function parseGeneratedText(text) {
//   const lines = text.split('\n');
//   return {
//     caseName: (lines[1]).replace(/^"Generated Text: 1. Case Name:\s*/, '').replace(/"$/, '')  || 'null',
//     sections:( lines[1]).replace(/^"2\. Relevant Legal Sections:\s*/, '').replace(/"$/, '')    || 'null',
//     crime: (lines[2]).replace(/^"3.\. **Crime Committed:**\s*/, '').replace(/"$/, '')  || 'null',
//     riskOfFlight: (lines[3]). replace(/^" **Risk of Flight:** \s*/, '').replace(/"$/, '') || 'null',
//     cityState: lines[1] || 'null',
//     bailStatus: lines[1] || 'null',
//     courtName: lines[1] || 'null',
//     judgeName: lines[1] || 'null',
//     damage:lines[1] || 'null',
//   };
// }
function parseGeneratedText(text) {
  const lines = text.split('\n');
  console.log("line0",lines[0]);
  console.log("line1",lines[1]);
  console.log("line2",lines[2]);
  console.log("line3",lines[3]);
  console.log("line4",lines[4]);
  console.log("line5",lines[5]);
  console.log("line6",lines[6]);
  console.log("line7",lines[7]);
  console.log("line8",lines[8]);
  return {
    caseName: extractField(lines[0], "1\\. \\*\\*Case Name:\\*\\*") || 'null',
    sections: extractField(lines[1], "2\\. \\*\\*Relevant Legal Sections:\\*\\*") || 'null',
    crime: extractField(lines[2], "3\\. \\*\\*Crime Committed:\\*\\*") || 'null',
    riskOfFlight: extractField(lines[3], "4\\. \\*\\*Risk of Flight:\\*\\*") || 'null',
    cityState: extractField(lines[4], "5\\. \\*\\*City and State of the Case:\\*\\*") || 'null',
    bailStatus: extractField(lines[5], "6\\. \\*\\*Bail Status:\\*\\*") || 'null',
    courtName: extractField(lines[6], "7\\. \\*\\*Court Name:\\*\\*") || 'null',
    judgeName: extractField(lines[7], "8\\. \\*\\*Name of the Judge:\\*\\*") || 'null',
    damage: extractField(lines[8], "9\\. \\*\\*The damage:\\*\\*") || 'null',
  };
}

function extractField(line, prefix) {
  if (!line || !prefix) return null;
  const regex = new RegExp(`^${prefix}\\s*`);
  return line.replace(regex, '').trim();
}

async function saveToCSV(data) {
  const filePath = path.resolve('judgment_data.csv');
  
  let existingRecords = [];
  if (fs.existsSync(filePath)) {
    const csvContent = fs.readFileSync(filePath, 'utf8');
    existingRecords = csvContent.split('\n').map(line => line.trim()).filter(line => line !== '');
  }

  const dataString = `${data.caseName},${data.sections},${data.crime},${data.riskOfFlight},${data.cityState},${data.bailStatus},${data.courtName},${data.judgeName},${data.damage}`;

  if (!existingRecords.includes(dataString)) {
    fs.appendFileSync(filePath, `\n${dataString}`);
    console.log('Data appended to CSV.');
  } else {
    console.log('Duplicate entry found. Skipping...');
  }
}



async function main() {
  const urls = [
    'https://indiankanoon.org/doc/1108032/',
    'https://indiankanoon.org/doc/1709116/', 
'https://indiankanoon.org/doc/27212659/', 
'https://indiankanoon.org/doc/27212659/', 
'https://indiankanoon.org/doc/1616817/', 
'https://indiankanoon.org/doc/1041199/', 
'https://indiankanoon.org/doc/108661111/', 
'https://indiankanoon.org/doc/196154091/', 
'https://indiankanoon.org/doc/80142656/', 
'https://indiankanoon.org/doc/172507933/', 
'https://indiankanoon.org/doc/214178/', 
'https://indiankanoon.org/doc/135890926/', 
'https://indiankanoon.org/doc/15312633/', 
'https://indiankanoon.org/doc/91721247/', 
'https://indiankanoon.org/doc/181480145/', 
'https://indiankanoon.org/doc/184135932/', 
'https://indiankanoon.org/doc/44858094/', 
'https://indiankanoon.org/doc/181059879/', 
'https://indiankanoon.org/doc/524292/', 
'https://indiankanoon.org/doc/93083538/', 
'https://indiankanoon.org/doc/16234510/', 
'https://indiankanoon.org/doc/40997826/', 
'https://indiankanoon.org/doc/166905030/', 
'https://indiankanoon.org/doc/1020289/', 
'https://indiankanoon.org/doc/21895456/', 
'https://indiankanoon.org/doc/46624/', 
'https://indiankanoon.org/doc/127146366/', 
'https://indiankanoon.org/doc/803385/', 
'https://indiankanoon.org/doc/150222296/', 
'https://indiankanoon.org/doc/660774/', 
'https://indiankanoon.org/doc/481760/', 
'https://indiankanoon.org/doc/80066658/'

    
  ];

  for (const url of urls) {
    try {
      console.log(`Processing URL: ${url}`);
      const judgmentContent = await fetchJudgmentContent(url);
      const extractedData = await queryGemini(judgmentContent);
      if (extractedData) {
        await saveToCSV(extractedData);
    
      }
    } catch (error) {
      console.error(`Failed to process URL ${url}:`, error);
    }
  }
}

// Run the main function
main();













