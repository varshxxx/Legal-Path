

const express = require('express');
const cors = require('cors');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { google } = require('googleapis');
const { GoogleAuth } = require('google-auth-library');
const path = require('path');
const bodyParser = require('body-parser');

require('dotenv').config();

const app = express();

// Enable CORS for all routes
app.use(cors());

app.use(bodyParser.json());

const API_KEY = process.env.API_KEY;

app.post('/queryGemini', async (req, res) => {
  const caseDetails = req.body.caseDetails;

  if (!caseDetails) {
    return res.status(400).json({ error: "Case details are required." });
  }

  try {
    const genAI = new GoogleGenerativeAI(API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    console.log("started",{caseDetails});
    const prompt = `You are a legal assistant mapping IPC and CRPC mappings.  ${caseDetails}
    The result should be only two  lines.What is the IPC section numbers and coresponding CRPC section numbers alone` ;

    const result = await model.generateContent(prompt);
    const generatedText = result.response.candidates[0]?.content || 'No content generated.';
    console.log(generatedText);
    // Send the generated response as JSON
    res.json({ generatedText });
  } catch (error) {
    console.error("Error querying Gemini:", error);
    res.status(500).json({ error: "Error querying Gemini API." });
  }
});


//Get the case number,name from the fir in Lawyers Page
app.post('/queryGeminifordet',async(req,res)=>
{
  
})

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
