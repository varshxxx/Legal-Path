document.getElementById('generate-btn').addEventListener('click', async function () {
    const fileInput = document.getElementById('fir-file');
    const file = fileInput.files[0];

    if (!file) {
        alert('Please select an FIR PDF file first.');
        return;
    }

    // Show loading indicator
    document.getElementById('loading').style.display = 'block';
    document.getElementById('bail-petition').style.display = 'none';

    const formData = new FormData();
    formData.append('firPdf', file);

    try {
        const response = await fetch('/generate-bail-petition', {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error('Failed to generate bail petition');
        }

        const data = await response.json();
        document.getElementById('loading').style.display = 'none';
        document.getElementById('bail-petition').style.display = 'block';
        document.getElementById('bail-petition').textContent = data.bailPetition;

    } catch (error) {
        console.error('Error generating bail petition:', error);
        document.getElementById('loading').style.display = 'none';
        alert('Failed to generate bail petition');
    }
});
